# OpenIC
OpenIC is an open-source input library used for multiple-purposes.
